L2 buff log monitor

This is a read-only diagnostic LOG monitor, NOT a network packet sniffer.
It does not cast skills, inject input, or send commands to the game.

Requirements: Windows and Python 3 with tkinter (standard python.org installer).
No third-party Python packages are required.

Run Start-Monitor.cmd. Default log: F:\BOH pts\system\l2.log.
For another path use:
python monitor.py --log "C:\path\to\system\l2.log"

IMPORTANT: the client must already emit L2PA_BEGIN diagnostic records.
An unmodified client will not supply these records. This archive does NOT
include the game client, Interface.u, or a client patch installer.
The recipient needs a compatible diagnostic client to receive live data.

Supported data: party status and effects; self normal effects event 950.
Temporary self clears without ServerID are ignored.
Outputs are created in runtime/ next to the program.
Existing records are replayed on startup; displayed receipt times do not
prove that historical records are live. The viewer is diagnostic only.

Archive contains no captured logs, character data, credentials or rebuff bot.
