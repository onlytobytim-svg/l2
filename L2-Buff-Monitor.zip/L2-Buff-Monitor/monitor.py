"""Read-only BOH party diagnostic log viewer. Does not control the game."""
import argparse,json,re,time,codecs
from pathlib import Path
from party_state import PartyState
KINDS={1140:'party_add',1150:'party_update',1160:'party_remove',1170:'party_clear',1180:'effects_snapshot',1050:'effects_snapshot',1182:'effects_remove',1052:'effects_remove',1183:'effects_insert',1053:'effects_insert'}
class Decoder:
 def __init__(self):self.pending=None
 def feed(self,line):
  marker='L2PA_BEGIN|'
  if marker in line:
   self.pending={'source':line.split(marker,1)[1].strip(),'stage':0};return None
  if self.pending is None:return None
  # Only consume adjacent diagnostic lines, never unrelated chat/system lines.
  msg=re.sub(r'^.*?(?:ScriptLog|Log|Debug):\s*','',line).strip()
  if self.pending['stage']==0:
   if not re.fullmatch(r'-?\d+',msg):self.pending=None;return None
   self.pending['event_id']=int(msg);self.pending['stage']=1;return None
  item=self.pending;self.pending=None
  return {'received_at':time.time(),'source':item['source'],'event_id':item['event_id'],'kind':KINDS.get(item['event_id'],'other'),'raw_parameters':msg}
class Tail:
 def __init__(self,path):self.path=path;self.offset=0;self.text='';self.decoder=codecs.getincrementaldecoder('utf-16-le')('replace');self.stamp=None
 def poll(self):
  try:
   stat=self.path.stat()
   stamp=(stat.st_dev,stat.st_ino)
   if stamp!=self.stamp or stat.st_size<self.offset:
    self.offset=0;self.text='';self.decoder.reset();self.stamp=stamp
   with self.path.open('rb') as f:f.seek(self.offset);b=f.read();self.offset=f.tell()
  except (FileNotFoundError,PermissionError):return []
  self.text+=self.decoder.decode(b).lstrip('\ufeff')
  parts=self.text.split('\n');self.text=parts.pop()
  return [p.rstrip('\r') for p in parts]
def main():
 import tkinter as tk
 from tkinter.scrolledtext import ScrolledText
 ap=argparse.ArgumentParser();ap.add_argument('--log',default=r'F:\BOH pts\system\l2.log');args=ap.parse_args()
 state=PartyState()
 window=tk.Tk();window.title('L2 Party — диагностический монитор');window.geometry('900x550')
 label=tk.Label(window,text='Ожидание диагностических событий. Данные игры пока не получены.',anchor='w');label.pack(fill='x')
 box=ScrolledText(window,wrap='word');box.pack(fill='both',expand=True)
 paths=[Path(args.log),Path(args.log).with_name('l2Second.log')]; sources=[(Tail(p),Decoder()) for p in dict.fromkeys(paths)];count=0
 out=Path(__file__).parent/'runtime';out.mkdir(exist_ok=True)
 def poll():
  nonlocal count
  try:
   events=[]
   for tail,decoder in sources:
    for line in tail.poll():
     event=decoder.feed(line)
     if event:
      event['log_file']=str(tail.path);events.append(event)
   for event in events:
    if event:
     count+=1;label.config(text=f'Получено событий: {count} | Последнее: {event["kind"]}')
     changes=state.apply(event)
     text=json.dumps(event,ensure_ascii=False)
     for change in changes:
      with (out/'buff-changes.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(change,ensure_ascii=False)+'\n')
      box.insert('end','БАФ: '+json.dumps(change,ensure_ascii=False)+'\n')
     with (out/'party-events.jsonl').open('a',encoding='utf-8') as f:f.write(text+'\n')
     box.insert('end',text+'\n');box.see('end')
     if int(box.index('end-1c').split('.')[0])>300:box.delete('1.0','100.0')
  except Exception as e:label.config(text='Ошибка чтения: '+str(e))
  window.after(200,poll)
 poll();window.mainloop()
if __name__=='__main__':main()
