import re
# Names correlated with the user's two-buff live test; extend after verification.
SKILLS={1242:'Death Whisper',1036:'Magic Barrier'}
def fields(raw):
 matches=list(re.finditer(r'(?:^|\s)([A-Za-z][A-Za-z0-9_]*)=',raw));out={}
 for i,m in enumerate(matches):
  value=raw[m.end():matches[i+1].start() if i+1<len(matches) else len(raw)].strip()
  out[m.group(1)]=int(value) if re.fullmatch(r'-?\d+',value) else value.strip('\x7f').split(';')[0]
 return out
class PartyState:
 def __init__(self):self.members={}
 def apply(self,event):
  f=fields(event['raw_parameters']);source=event.get('log_file','unknown');eid=event['event_id']
  is_self=eid==950 and event.get('source')=='AbnormalStatusWnd.OnEvent'
  if eid==950:
   # The client emits a temporary Max=0 clear before the real snapshot.
   # Only the real snapshot carries ServerID, including actual empty buffs.
   if not is_self or not isinstance(f.get('ServerID'),int):return []
   f['ID']=f['ServerID']
   eid=1180
  if eid==1170:
   self.members={k:v for k,v in self.members.items() if k[0]!=source};return []
  if not isinstance(f.get('ID'),int):return []
  key=(source,f['ID'])
  if eid==1160:self.members.pop(key,None);return []
  if eid not in (1140,1150,1180):return []
  member=self.members.setdefault(key,{'id':f['ID'],'source':source,'effects':None})
  if eid in (1140,1150):
   member.update({k:v for k,v in f.items() if k!='ID'});return []
  count=f.get('Max')
  if not isinstance(count,int) or not 0<=count<=1024:return []
  new={}
  for i in range(count):
   skill=f.get(f'ClassID_{i}');level=f.get(f'{"SkillLevel" if is_self else "Level"}_{i}');sub=f.get(f'{"SkillSubLevel" if is_self else "SubLevel"}_{i}',0)
   if not isinstance(skill,int) or not isinstance(level,int):return []
   new[(skill,level,sub)]={'skill_id':skill,'name':SKILLS.get(skill,str(skill)),'level':level,'sublevel':sub,'seconds':f.get(f'{"RemainTime" if is_self else "Sec"}_{i}'),'raw_speller_id':f.get(f'SpellerID_{i}')}
  if is_self:member['is_self']=True
  old=member['effects'];member['effects']=new;member['last_effect_update']=event['received_at']
  if old is None:return [{'action':'baseline','member_id':f['ID'],'count':len(new),'source':source}]
  changes=[]
  for action,keys,items in [('removed',old.keys()-new.keys(),old),('added',new.keys()-old.keys(),new)]:
   for k in sorted(keys):changes.append({'action':action,'member_id':f['ID'],'source':source,**items[k]})
  return changes
